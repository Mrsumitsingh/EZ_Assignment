

// import Form from "./Pages/Form/Form";
// import Home from "./Pages/Home/Home";
// import Nav from "./Pages/Nav/Nav";
// const App = ()=>{
//   return(
//     <div>
//       <Nav/>
//       <Home/>

//     </div>
//   )
// }
// export default App;

import { BrowserRouter, Routes, Route } from "react-router-dom";
// import Nav from "./components/Nav";
import Home from "./Pages/Home/Home";
import Form from "./Pages/Form/Form";
import Nav from "./Pages/Nav/Nav";
// import Contact from "./pages/Contact";

function App() {
  return (
    <BrowserRouter>
      <Nav />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/contact" element={<Form/>} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;

