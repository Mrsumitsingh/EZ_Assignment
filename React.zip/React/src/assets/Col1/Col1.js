import BackGround from "./BG.png";
import Logo from "./VFilmsLogo.png"
import Mandala from "./HeroMandala.png"

export const images={
    BackGround,
    Logo,
    Mandala
}