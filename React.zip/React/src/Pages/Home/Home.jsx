
import "./Home.css"
import { images } from "../../assets/Col1/Col1"
function Home(){


    return(
        
            <div className="MainContainer">

    <div className="card-container" style={{backgroundImage : `url(${images.BackGround})`}}>


        <div className="left-box" style={{ height: '100vh' }}>

          
          <div className="mandala-box">
            <img
          src={images.Mandala}
          alt="mandala"
          className="mandala-img"
            />

            <div className="logo-box">
             <img src={images.Logo} alt="" />
            </div>
          </div>
        </div>

        {/* RIGHT SIDE */}
      <div className="right-box">
        <h1 className="main-title">
          Varnan is where stories find <br />
          their voice and form
        </h1>

        <div className="subtitle-box">
          Films · Brands · Art
        </div>

        <div className="desc-box">
          Since 2009, V’ve been telling stories – stories of people,
          their journeys, and the places that shape them.
          Some begin in polished boardrooms, others in humble
          village squares. But every story starts the same way – by
          listening with intention. V believes it takes trust, patience,
          and an eye for the unseen to capture what truly matters.
          V doesn’t just tell stories – V honors them.
        </div>
      </div>

    </div>


    <h3>Hero/openNavigation</h3>


    



    </div>
        
    )
}

export default Home