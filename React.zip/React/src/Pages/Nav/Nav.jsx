// import React from 'react';
// import './Nav.css'; // Make sure to create this CSS file for styling

// const Nav = () => {
//     return (
//         <nav className="navbar">
//             <ul className="nav-list">
//                 <li className="nav-item"><a href="/">Home</a></li>
//                 <li className="nav-item"><a href="/form">Form</a></li>
//             </ul>
//         </nav>
//     );
// };

// export default Nav;


// Nav.jsx
import { Link } from 'react-router-dom';
import Form from "../Form/Form";
import Home from "../Home/Home";
import "./Nav.css";


function Nav() {
  return (
     <nav className="navbar">
      <div className="logo">MySite</div>

      <ul className="nav-links">
        <li><Link to="/">Home</Link></li>
        <li><Link to="/contact">Contact</Link></li>
      </ul>

   
    </nav>
  );
}

export default Nav;
