import React, { useState } from "react";
import "./Form.css"

function Form() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    setError(null);

    // Validate email format
    if (name === "email") {
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(value)) {
        setError("Please enter a valid email address.");
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.name || !formData.email || !formData.message) {
      setError("Please fill all required fields (*)");
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch('https://vernanbackend.ezlab.in/api/contact-us/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData)
      });

      if (!response.ok) {
        throw new Error('Failed to submit form');
      }

      const data = await response.json();
      setSubmitted(true);
      setFormData({ name: "", email: "", phone: "", message: "" });
    } catch (err) {
      setError(err.message || 'Something went wrong! Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="contact-page">
      <header className="header">
        <div className="logo">
          <span className="v">V</span> Films
        </div>
      </header>

      <div className="content">
        <div className="left-section">
          <p>
            Whether you have an idea, a question, or simply want to explore how V can work together,
            V’re just a message away.
          </p>
          <p>Let’s catch up over coffee.</p>
          <p>Great stories always begin with a good conversation.</p>
        </div>

        <div className="right-section">
          <h2 className="fade-in">Join the Story</h2>
          <p className="fade-in-delay">Ready to bring your vision to life? Let’s talk.</p>

          {!submitted ? (
            <form className="contact-form" onSubmit={handleSubmit}>
              {error && <div className="error-message">{error}</div>}
              <input
                type="text"
                name="name"
                placeholder="Your name*"
                value={formData.name}
                onChange={handleChange}
                required
                disabled={loading}
              />
              <input
                type="email"
                name="email"
                placeholder="Your email*"
                value={formData.email}
                onChange={handleChange}
                required
                disabled={loading}
              />
              <input
                type="tel"
                name="phone"
                placeholder="Phone"
                value={formData.phone}
                onChange={handleChange}
                disabled={loading}
              />
              <textarea
                name="message"
                placeholder="Your message*"
                value={formData.message}
                onChange={handleChange}
                required
                disabled={loading}
              ></textarea>
              <button type="submit" className="btn-animate" disabled={loading}>
                {loading ? "Submitting..." : "Submit"}
              </button>
            </form>
          ) : (
            <div className="success-message fade-in">
              <h3>Thank you!</h3>
              <p>Your message has been sent successfully. We’ll get back to you soon.</p>
              <button className="btn-animate" onClick={() => setSubmitted(false)}>
                Send another message
              </button>
            </div>
          )}

          <div className="contact-info fade-in-delay">
            <a href="mailto:vernita@varmanfilms.co.in">vernita@varmanfilms.co.in</a>
            <span>+91 98736 84567</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Form;
